<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\image;

class CatsController extends Controller
{
    public function AllCats(){
        return view('welcome', [
            'result' => image::all()
        ]);
    }

    public function Adatlap($id){
        return view('adatlap',[
        'result' => image::find($id)
    ]);
    }

    public function Authors(){
        return view('authors',[
            'result' => image::select('author','author_link')
                                ->distinct()
                                ->orderBy('author')
                                ->get(),
                                'sv'=>1
        ]);
    }

    public function Random(){
        return view('random',[
            'result' => image::inRandomOrder()
                                ->first()
        ]);
    }
}


