@extends('layout')
@section('content')
<div class="container pb-2">
    <h1 class="text-center display-6 py-3">{{$result->title}}</h1>
    <div class="row">
        <div class="col-md">
            <p>
                <img src="{{asset('img/'.$result->id.'.jpg')}}" alt="{{$result->id}}'.jpg'" class="w-100">
            </p>

        </div>
        <div class="col-md">
        <table class="table table-bordered">
            <tr>
                <th>stock image page</th>
                <td><a href="https://{{$result->site}}" target="_blank">{{$result->site}}</a></td>
            </tr>
            <tr>
                <th>Direct link to pic</th>
                <td><a href="https://{{$result->direct_link}}" target="_blank">{{$result->direct_link}}</a></td>
            </tr>
            <tr>
                <th>Author</th>
                <td>{{$result->author}}</td>
            </tr>
            <tr>
                <th>Author's page</th>
                <td><a href="https://{{$result->author_link}}" target="_blank">{{$result->author_link}}</a></td>
            </tr>
        </table>
        </div>

    </div>
</div>
@endsection
