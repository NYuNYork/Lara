@extends('layout')
@section('content')
<div class="container pb-2">
    <h1 class="text-center display-6 py-3">Cats pics</h1>
    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th>Author name</th>
            <th>Author's page</th>
        </tr>
        @foreach ($result as $row)
            <tr>
                <td>{{$sv++}}</td>
                <td>{{$row->author}}</td>
                <td><a href="https://{{$row->author_link}}" target="_blank">{{$row->author_link}}</a></td>
            </tr>
        @endforeach
    </table>
</div>
@endsection
