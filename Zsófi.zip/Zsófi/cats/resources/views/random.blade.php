@extends('layout')
@section('content')
<div class="container pb-2">
    <h1 class="text-center display-6 py-3">{{$result->title}}</h1>

    <p><img src="{{asset('img/'.$result->id.'.jpg')}}" alt="{{$result->id}}" class="w-100"></p>
</div>
@endsection
