<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CatsController;

Route::get('/', [CatsController::class, 'AllCats']);
Route::get('/cats-page/{id}',[CatsController::class, 'Adatlap']);
Route::get('/authors',[CatsController::class, 'Authors']);
Route::get('/random',[CatsController::class, 'Random']);

