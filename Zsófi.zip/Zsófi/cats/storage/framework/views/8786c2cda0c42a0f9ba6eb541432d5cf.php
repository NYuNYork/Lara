<?php $__env->startSection('content'); ?>
<div class="container pb-2">
    <h1 class="text-center display-6 py-3"><?php echo e($result->title); ?></h1>
    <div class="row">
        <div class="col-md">
            <p>
                <img src="<?php echo e(asset('img/'.$result->id.'.jpg')); ?>" alt="<?php echo e($result->id); ?>'.jpg'" class="w-100">
            </p>

        </div>
        <div class="col-md">
        <table class="table table-bordered">
            <tr>
                <th>stock image page</th>
                <td><a href="https://<?php echo e($result->site); ?>" target="_blank"><?php echo e($result->site); ?></a></td>
            </tr>
            <tr>
                <th>Direct link to pic</th>
                <td><a href="https://<?php echo e($result->direct_link); ?>" target="_blank"><?php echo e($result->direct_link); ?></a></td>
            </tr>
            <tr>
                <th>Author</th>
                <td><?php echo e($result->author); ?></td>
            </tr>
            <tr>
                <th>Author's page</th>
                <td><a href="https://<?php echo e($result->author_link); ?>" target="_blank"><?php echo e($result->author_link); ?></a></td>
            </tr>
        </table>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Zsófi\cats\resources\views/adatlap.blade.php ENDPATH**/ ?>