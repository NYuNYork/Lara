    
    <?php $__env->startSection('content'); ?>
    <div class="container pb-2">
        <h1 class="text-center display-6 py-3">Cats pics</h1>
        <div class="row">
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
            <p>
            <img class="w-100" src="<?php echo e(asset('img/'.$row->id.'.jpg')); ?>" alt="<?php echo e($row->id); ?>.jpg">
            </p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_13AB3\cats\resources\views/welcome.blade.php ENDPATH**/ ?>