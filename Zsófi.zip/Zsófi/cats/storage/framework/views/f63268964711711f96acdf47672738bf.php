<?php $__env->startSection('content'); ?>
<div class="container pb-2">
    <h1 class="text-center display-6 py-3"><?php echo e($result->title); ?></h1>

    <p><img src="<?php echo e(asset('img/'.$result->id.'.jpg')); ?>" alt="<?php echo e($result->id); ?>" class="w-100"></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Zsófi\cats\resources\views/random.blade.php ENDPATH**/ ?>