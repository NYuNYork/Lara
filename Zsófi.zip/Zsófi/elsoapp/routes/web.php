<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TanfolyamokController;

// Route::get('/', function () {
//     return view('welcome');
// });

route::get('/',[TanfolyamokController::class, 'welcome'])
Route::get('/angol', function () {
    return view('angol');
});
Route::get('/nemet', function () {
    return view('nemet');
});
Route::get('/orosz', function () {
    return view('orosz');
});
