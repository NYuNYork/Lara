<?php $__env->startSection('title','Angol nyelvtanfolyam'); ?>
<?php $__env->startSection('content'); ?>
<main class="container pt-3 fs-4">
    <h2 class="text-center"><b>Angol nyelvtanfolyam</b></h2>
    <section>
        <h3>Oldal alcíme</h3>
        <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos qui voluptas libero facilis accusantium nemo fuga doloribus magni iste, nesciunt placeat. Animi tenetur qui quas beatae blanditiis ab dolores quam.
        </p>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi excepturi est quam nobis sint cumque amet recusandae maxime corporis, laudantium id minus mollitia porro, accusantium fugit odio, ratione reprehenderit sunt?
        </p>
        <hr>
    </section>
    <section>
        <h3>Oldal alcíme</h3>
        <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quos qui voluptas libero facilis accusantium nemo fuga doloribus magni iste, nesciunt placeat. Animi tenetur qui quas beatae blanditiis ab dolores quam.
        </p>
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi excepturi est quam nobis sint cumque amet recusandae maxime corporis, laudantium id minus mollitia porro, accusantium fugit odio, ratione reprehenderit sunt?
        </p>
        <hr>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_13AB3\elsoapp\resources\views/angol.blade.php ENDPATH**/ ?>