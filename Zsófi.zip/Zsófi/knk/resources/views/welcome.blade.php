<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sablon - írd át!</title>
    <!-- Bootswatch Cosmo Theme -->
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/bootstrap.bundle.js"></script>
    <!-- Font Awesome Solid -->
    <link href="assets/fontawesome/css/fontawesome.css" rel="stylesheet">
    <link href="assets/fontawesome/css/solid.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg bg-dark py-2 sticky-top" data-bs-theme="dark">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fa-solid fa-map"></i> Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#CosmoNavbar" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="CosmoNavbar">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Link1</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Link2</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Link3</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Link4</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                        <div class="dropdown-menu">
                          <a class="dropdown-item" href="#">Link5</a>
                          <a class="dropdown-item" href="#">Link6</a>
                          <a class="dropdown-item" href="#">Link7</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <main class="container py-3 px-5">
        <section>
            <h1>Headings 2</h1>
            <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam quas nesciunt perspiciatis eligendi quos, labore quod accusamus neque, voluptate cupiditate molestias tenetur pariatur? At illo, rerum corrupti distinctio aliquam nemo!
            </p>
            <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam quas nesciunt perspiciatis eligendi quos, labore quod accusamus neque, voluptate cupiditate molestias tenetur pariatur? At illo, rerum corrupti distinctio aliquam nemo!
            </p>
            <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam quas nesciunt perspiciatis eligendi quos, labore quod accusamus neque, voluptate cupiditate molestias tenetur pariatur? At illo, rerum corrupti distinctio aliquam nemo!
            </p>
            <hr>
        </section>
        <section>
            <h1>Headings 2</h1>
            <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam quas nesciunt perspiciatis eligendi quos, labore quod accusamus neque, voluptate cupiditate molestias tenetur pariatur? At illo, rerum corrupti distinctio aliquam nemo!
            </p>
            <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam quas nesciunt perspiciatis eligendi quos, labore quod accusamus neque, voluptate cupiditate molestias tenetur pariatur? At illo, rerum corrupti distinctio aliquam nemo!
            </p>
            <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam quas nesciunt perspiciatis eligendi quos, labore quod accusamus neque, voluptate cupiditate molestias tenetur pariatur? At illo, rerum corrupti distinctio aliquam nemo!
            </p>
        </section>
    </main>
    <footer class="my-4 text-center">
        <p>Footer text</p>
    </footer>
</body>
</html>
