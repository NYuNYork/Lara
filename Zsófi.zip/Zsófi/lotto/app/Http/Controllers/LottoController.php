<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\otos;

class LottoController extends Controller
{
    public function Welcome(){
        ## SELECT ev FROM otos GROUPBY ev
        return view('welcome',[
            'result' => otos::select('ev')
                                ->groupBy('ev')
                                ->get()
        ]);

    }
    public function ev($p){
        return view('ev',[
            'result' => otos::select('id', 'het')
                                ->where('ev',$p)
                                ->get(),
            'ev' => $p
        ]);
    }
    public function adatlap($id){
        return view('adatlap',[
            'result' => otos::find($id)            ##KURVA FONTOS
        ]);
    }
    public function Mikor(){
        return view('mikor', [
            ##SELECT ev, het, talalat5_db, talalat5_huf FROM otos WHERE talalat5_db >0 AND ev>1998
            'result' => otos::select('ev','het','talalat5_db','talalat5_huf')
                                ->where('talalat5_db','>',0)
                                ->where('ev','>',1998)
                                ->get(),
            'sv' => 1
        ]);
    }
}

