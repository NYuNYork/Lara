
@extends('layout')
@section('content')
<div class="container py-3">
    <h1 class="text-center display-5">Sample title</h1>
    <p class="fs-4">Válassz egy hetet, hogy megnézd a húzás adatait</p>
    <table class="table table-striped">
        <tr>
            <th>#</th>
            <th>Év</th>
            <th>Hét</th>
            <th>Darab</th>
            <th>HUF</th>
        </tr>
        @foreach ($result as $row)
        <tr>
            <td>{{$sv}}</td>
            <td>{{$row->ev}}</td>
            <td>{{$row->het}}</td>
            <td>{{$row->talalat5_db}}</td>
            <td>{{number_format($row->talalat5_huf,0,',',' ')}} FT</td>
        </tr>
        @endforeach
    </table>
