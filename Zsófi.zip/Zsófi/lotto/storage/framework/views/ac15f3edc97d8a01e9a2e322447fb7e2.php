<?php $__env->startSection('content'); ?>
<div class="container py-3">
    <h1 class="text-center display-5"><?php echo e($result->ev); ?> - <?php echo e($result->het); ?>. hét</h1>
    <div class="row">
        <div class="col-md">
            <p class="fs-4">
                Az ötös lottó nyerőszámai:<br>
                <?php echo e($result->szam1); ?>

                <?php echo e($result->szam2); ?>

                <?php echo e($result->szam3); ?>

                <?php echo e($result->szam4); ?>

                <?php echo e($result->szam5); ?>


            </p>
        </div>
        <div class="">
            <?php if($result->talalat2_db>0): ?>
                <table class="table">
                    <tr>
                        <th>
                        </th>
                        <th>Darab</th>
                        <th>HUF</th>
                    </tr>
                    <tr>
                        <td>Öt találatos</td>
                        <td><?php echo e($result->talalat5_db); ?></td>
                        <td><?php echo e(number_format($result->talalat5_huf,0,',',' ')); ?> FT</td>
                    </tr>
                    <tr>
                        <td>Négy találatos</td>
                        <td><?php echo e($result->talalat4_db); ?></td>
                        <td><?php echo e(number_format($result->talalat4_huf,0,',',' ')); ?> FT</td>
                    </tr>
                    <tr>
                        <td>Három találatos</td>
                        <td><?php echo e($result->talalat3_db); ?></td>
                        <td><?php echo e(number_format($result->talalat3_huf,0,',',' ')); ?> FT</td>
                    </tr>
                    <tr>
                        <td>Kettő találatos</td>
                        <td><?php echo e($result->talalat2_db); ?></td>
                        <td><?php echo e(number_format($result->talalat2_huf,0,',',' ')); ?> FT</td>
                    </tr>
                    <tr>
                        <td>Egy találatos</td>
                        <td><?php echo e($result->talalat1_db); ?></td>
                        <td><?php echo e(number_format($result->talalat1_huf,0,',',' ')); ?> FT</td>
                    </tr>
                </table>
            <?php else: ?>
                <p class="fs-4">A nyereményekről nincs adat</p>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Zsófi\lotto\resources\views/adatlap.blade.php ENDPATH**/ ?>