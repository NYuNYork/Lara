        
        <?php $__env->startSection('content'); ?>
    <div class="container py-3">
        <h1 class="text-center display-5">Sample title</h1>
        <p class="fs-4">
        Válassz egy évet
        </p>
        <p class="fs-4">
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="btn btn-primary fs-4 mb-2" href="/ev/<?php echo e($sv->ev); ?>"><?php echo e($sv->ev); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Zsófi\lotto\resources\views/welcome.blade.php ENDPATH**/ ?>