<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\pizzak;

class PizzakController extends Controller
{
    public function akcios(){
        return view("welcome",[
            'result' => pizzak::where('akcios',1)
                                ->get()
        ]);
    }
}
