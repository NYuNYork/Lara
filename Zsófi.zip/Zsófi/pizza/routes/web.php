<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PizzakController;

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', [PizzakController::class, 'akcios']);
