    
    <?php $__env->startSection('content'); ?>
    <div class="container py-3">
        <h1 class="text-center display-5">Sample title</h1>
        <p class="fs-4">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam eum laudantium quisquam. Consequuntur vel quod placeat autem eum vero totam facilis? Vel totam cum maiores animi eveniet modi eligendi veritatis!
        </p>
        <p class="fs-4">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam eum laudantium quisquam. Consequuntur vel quod placeat autem eum vero totam facilis? Vel totam cum maiores animi eveniet modi eligendi veritatis!
        </p>
        <p class="fs-4">
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam eum laudantium quisquam. Consequuntur vel quod placeat autem eum vero totam facilis? Vel totam cum maiores animi eveniet modi eligendi veritatis!
        </p>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_13AB3\pizza\resources\views/welcome.blade.php ENDPATH**/ ?>