@extends('layout')
@section('content')
<main class="container pb-2">
    <h1 class="text-center display-6 py-3">Happy Travel</h1>
    <p class="fs-5">
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nobis repellendus perspiciatis nisi? Voluptatem libero minima debitis doloribus ducimus repudiandae assumenda quis magni modi vero autem, velit dolore inventore dignissimos voluptates!
    </p>
</main>
@endsection
