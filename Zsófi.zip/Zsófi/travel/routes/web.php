<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TravelController;

Route::get('/', [TravelController::class, 'AllTravel']);
Route::get('/uticel/{p}', [TravelController::class, 'Uticel']);
Route::get('/adatlap/{id}',[TravelController::class,'Adatlap']);
Route::get('/', function () {
    return view('welcome');
});

